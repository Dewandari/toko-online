-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Okt 2021 pada 07.30
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 7.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `material`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentar`
--

CREATE TABLE `komentar` (
  `id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `komentar` text NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `komentar`
--

INSERT INTO `komentar` (`id`, `email`, `komentar`, `waktu`) VALUES
(1, 'hikam@g.com', 'bagus', '2017-04-04 23:54:35'),
(2, 'hikam@gmail.com', 'ini kurang menarik', '2017-04-05 23:36:11'),
(3, 'ahmadsukino@mta.com', 'ini menurut saya websitenya simpel tapi okee...', '2017-04-11 22:41:44');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ongkir`
--

CREATE TABLE `ongkir` (
  `id` int(11) NOT NULL,
  `jarak` int(11) NOT NULL,
  `ongkir` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ongkir`
--

INSERT INTO `ongkir` (`id`, `jarak`, `ongkir`) VALUES
(1, 1, 10000),
(2, 2, 20000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian`
--

CREATE TABLE `pembelian` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `harga` int(20) NOT NULL,
  `jumlah` int(15) NOT NULL,
  `pembeli` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembelian`
--

INSERT INTO `pembelian` (`id`, `nama`, `harga`, `jumlah`, `pembeli`, `alamat`, `telepon`) VALUES
(32, 'Water Heater SL â€“ 182 SL', 36000000, 1, 'G', 'surakarta', 2147483647);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `harga` int(13) NOT NULL,
  `tag` varchar(11) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id`, `nama`, `isi`, `gambar`, `harga`, `tag`, `waktu`) VALUES
(29, 'Choc â€“ JT Panel 3D PerPcs', 'JT Panel 3D adalah produk dekorasi dinding yang layak diaplikasikan di berbagai jenis bangunan. Material ini sanggup mempercantik penampilan dinding, dan menutupi kelemahan dinding.\r\nCode = JTPanel3D\r\nUkuran = 50 cm x 50 cm\r\nKetebalan = 0,2 cm\r\nMin Pembelian = 4 Pcs / 1 m2', 'img/JT-Panel-1.jpg', 50000, 'pria', '2021-10-29 03:14:55'),
(30, 'BrickZephany â€“ JT Panel 3D PerPcs', 'JT Panel 3D adalah produk dekorasi dinding yang layak diaplikasikan di berbagai jenis bangunan. Material ini sanggup mempercantik penampilan dinding, dan menutupi kelemahan dinding. \r\nCode = JTPanel3D\r\nUkuran = 50 cm x 50 cm\r\nKetebalan = 0,2 cm\r\nMin Pembelian = 4 Pcs / 1 m2', 'img/JT-Panel-2.jpg', 50000, '', '2021-10-29 03:32:48'),
(31, 'Diamond â€“ JT Panel 3D PerPcs', 'JT Panel 3D adalah produk dekorasi dinding yang layak diaplikasikan di berbagai jenis bangunan. Material ini sanggup mempercantik penampilan dinding, dan menutupi kelemahan dinding.\r\nCode = JTPanel3D\r\nUkuran = 50 cm x 50 cm\r\nKetebalan = 0,2 cm\r\nMin Pembelian = 4 Pcs / 1 m2', 'img/JT-Panel-3-1.jpg', 50000, '', '2021-10-29 03:34:39'),
(32, 'JT Karpet Tile Black Stripe Permeter', 'JT Karpet Tile jenis ini banyak dipakai dalam perkantoran, apartemen, dan gedung-gedung karena kelebihannya yaitu membuat ruangan menjadi terlihat elegan, modern dan eksklusif.\r\nCode = JT Karpet 02\r\nPanjang = 50 cm\r\nLebar = 50 cm', 'img/karpet-1.jpg', 150000, '', '2021-10-29 03:38:32'),
(33, 'JT Karpet Tile Brown Permeter', 'JT Karpet Tile jenis ini banyak dipakai dalam perkantoran, apartemen, dan gedung-gedung karena kelebihannya yaitu membuat ruangan menjadi terlihat elegan, modern dan eksklusif.\r\nCode = JT Karpet 01\r\nPanjang = 50 cm\r\nLebar = 50 cm', 'img/karpet-2.jpg', 150000, '', '2021-10-29 03:40:49'),
(34, 'JT Karpet Tile Black Permeter', 'JT Karpet Tile jenis ini banyak dipakai dalam perkantoran, apartemen, dan gedung-gedung karena kelebihannya yaitu membuat ruangan menjadi terlihat elegan, modern dan eksklusif.\r\nCode = JT Karpet 02\r\nPanjang = 50 cm\r\nLebar = 50 cm', 'img/karpet-3.jpg', 150000, '', '2021-10-29 03:42:22'),
(35, 'JT Vinyl PVC PerMeter', 'Lantai JT Vinyl adalah material pelapis lantai yang terbukti handal. Permukaan lantai terasa halus, tahan lama, tersedia dalam aneka motif menawan, mudah pemasangan dan perawatannya, serta harganya sangat ekonomis.\r\nCode = JTVPVC\r\nPanjang = 92 cm\r\nLebar = 15 cm\r\nKetebalan = 2 mm\r\nQuantity = 24 pcs ( 3,3 m2 )', 'img/vinil-1.jpg', 128000, '', '2021-10-29 03:54:23'),
(36, 'JT Vinyl Korea 3 PerMeter', 'Harga tersebut di atas adalah harga per lembar, minimal pembelian satu box isi 3,34 meter harga per box 600rb ( 19 pcs), Lantai JT Vinyl Korea terbukti awet, karena mampu bertahan hingga puluhan tahun. Teksturnya nyaman dipijak, tersedia dalam aneka warna serta motif memikat, bahannya tidak berbahaya, dan cara pemasangan serta perawatan yang relatif mudah.\r\nCode = JTVKorea3\r\nPanjang = 94 cm\r\nLebar = 18 cm\r\nKetebalan = 3 mm\r\nQuantity = 19 pcs ( 3,3 m2 )', 'img/vinil-2.jpg', 32000, '', '2021-10-29 03:54:14'),
(37, 'JT Vinyl Korea 3 PerMeter', 'Harga tersebut di atas adalah harga per lembar, minimal pembelian satu box isi 3,34 meter harga per box 600rb ( 19 pcs), Lantai JT Vinyl Korea terbukti awet, karena mampu bertahan hingga puluhan tahun. Teksturnya nyaman dipijak, tersedia dalam aneka warna serta motif memikat, bahannya tidak berbahaya, dan cara pemasangan serta perawatan yang relatif mudah.\r\nCode = JTVKorea3\r\nPanjang = 94 cm\r\nLebar = 18 cm\r\nKetebalan = 3 mm\r\nQuantity = 19 pcs ( 3,3 m2 )', 'img/vinil-3.jpg', 32000, '', '2021-10-29 03:54:02'),
(38, 'Sanitary â€“ JT BD0116', 'Kami sediakan bermacam produk sanitary, seperti keran air dan drainase terbaik. Kualitasnya sudah terbukti bagus, dengan pilihan model yang menawan. Harganya pun sangat bersahabat. Sangat cocok diaplikasikan di rumah tinggal atau bangunan komersial.\r\nCode = JT BD0116', 'img/kran-3.jpg', 85000, '', '2021-10-29 04:00:38'),
(39, 'Sanitary â€“ JT BD0118', 'Kami sediakan bermacam produk sanitary, seperti keran air dan drainase terbaik. Kualitasnya sudah terbukti bagus, dengan pilihan model yang menawan. Harganya pun sangat bersahabat. Sangat cocok diaplikasikan di rumah tinggal atau bangunan komersial.\r\nCode = JT BD0118', 'img/kran-1.jpg', 70000, '', '2021-10-29 04:01:50'),
(40, 'Sanitary â€“ JT BD0122', 'Kami sediakan bermacam produk sanitary, seperti keran air dan drainase terbaik. Kualitasnya sudah terbukti bagus, dengan pilihan model yang menawan. Harganya pun sangat bersahabat. Sangat cocok diaplikasikan di rumah tinggal atau bangunan komersial.\r\nCode = JT BD0122', 'img/kran-2.jpg', 90000, '', '2021-10-29 04:02:49'),
(41, 'JT Roof â€“ Biru', 'JT Roof memiliki keunggulan yang sangat baik yang mana bahan yang digunakan adalah bahan UPVC yang sudah terkenal memiliki performa tinggi dengan anti UV dan heat protection additives. Atap UPVC Aman roof memiliki konduktifitas panas yang sangat rendah. Atap UPVC Aman roof tidak menyalurkan panas semudah atap dengan bahan lain.\r\nCode = JTRoof\r\nPanjang = 100 cm\r\nLebar = 890 cm\r\nTinggi Gelombang = 4 cm', 'img/plafon-1.jpg', 200000, '', '2021-10-29 04:07:09'),
(42, 'JT Roof â€“ Hijau', 'JT Roof memiliki keunggulan yang sangat baik yang mana bahan yang digunakan adalah bahan UPVC yang sudah terkenal memiliki performa tinggi dengan anti UV dan heat protection additives. Atap UPVC Aman roof memiliki konduktifitas panas yang sangat rendah. Atap UPVC Aman roof tidak menyalurkan panas semudah atap dengan bahan lain.\r\nCode = JTRoof\r\nPanjang = 100 cm\r\nLebar = 890 cm\r\nTinggi Gelombang = 4 cm', 'img/plafon-2.jpg', 200000, '', '2021-10-29 04:09:11'),
(43, 'JT Roof â€“ Merah', 'JT Roof memiliki keunggulan yang sangat baik yang mana bahan yang digunakan adalah bahan UPVC yang sudah terkenal memiliki performa tinggi dengan anti UV dan heat protection additives. Atap UPVC Aman roof memiliki konduktifitas panas yang sangat rendah. Atap UPVC Aman roof tidak menyalurkan panas semudah atap dengan bahan lain.\r\nCode = JTRoof\r\nPanjang = 100 cm\r\nLebar = 890 cm\r\nTinggi Gelombang = 4 cm', 'img/plafon-3.jpg', 200000, '', '2021-10-29 04:10:36'),
(44, 'Water Heater SL â€“ 181 SL', 'Solar water heating adalah alat konversi sinar matahari menjadi panas untuk memanaskan air menggunakan kolektor termal surya.\r\nCode = 181 SL\r\nBerat = 281 kg\r\nPanjang = 2.55 m\r\nTinggi = 0.51 m\r\nLebar	1.8 m\r\nPanel	1', 'img/wh-1.jpg', 31000000, '', '2021-10-29 04:57:19'),
(45, 'Water Heater SL â€“ 182 SL', 'Sistem kerja pemanasan air pada Solahart Direct Heating System yaitu air baku dipanaskan secara langsung di collector oleh sinar matahari dan disimpan didalam tangki.\r\nCode= 182 SL\r\nBerat = 325 kg\r\nPanjang = 2.55 m\r\nTinggi = 0.51 m\r\nLebar = 2.8 m\r\nPanel = 2', 'img/wh-2.jpg', 36000000, '', '2021-10-29 04:57:05'),
(46, 'Water Heater SL  â€“ 302 SL', 'Solar water heating adalah alat konversi sinar matahari menjadi panas untuk memanaskan air menggunakan kolektor termal surya.\r\nCode = 302 SL\r\nBerat = 562 kg\r\nPanjang = 2.55 m\r\nTinggi = 0.51 m\r\nLebar = 2.8 m\r\nPanel = 2', 'img/wh-3.jpg', 39000000, '', '2021-10-29 04:56:51');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(4, 'ndari', '0000');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `komentar`
--
ALTER TABLE `komentar`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `ongkir`
--
ALTER TABLE `ongkir`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `komentar`
--
ALTER TABLE `komentar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `ongkir`
--
ALTER TABLE `ongkir`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
