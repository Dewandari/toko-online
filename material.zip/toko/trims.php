<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="modul/style.css">
	<style>
		.trims{
			width: 600px;
			text-align: center;
			margin: 10% auto;
			font-size: 40px;
			background-color: #fff;
		}
		.trims a{
			font-size: 0.6em;
		}
	</style>
</head>
<body>
	
<div class="trims">
	<h1>Terima kasih</h1>
	<p>Anda yang terbaik</p>
	<a href="index.php" class="tmbl hijau">Belanja lagi</a>
	<p>&copy; Cari Bangunan</p>
</div>

</body>
</html>