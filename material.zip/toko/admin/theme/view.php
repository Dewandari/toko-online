<?php 
require_once 'fungsi.php';
 ?>
<?php function headerku(){ ?>
<!DOCTYPE html>
<html>
<head>
	<title>CP-admin</title>
	<link rel="stylesheet" type="text/css" href="theme/style.css">
	<link rel="icon" type="img/png" href="../img/logo.png">
</head>
<body>

<nav>

	<div class="brand">
		Hai <?= $_SESSION['nama'];  ?> !
	</div>

	<div class="konten">
		<ul>
			<a href="index.php"><li>Semua</li></a>
			<a href="add.php"><li>Tambah data</li></a>
			<a href="pembeli.php"><li>Pembeli</li></a>
			<a href="logout.php"><li>Logout</li></a>
		</ul>
		<form action="index.php" method="get">
			<input type="text" name="cari" placeholder="Cari disini...">
			<button>Cari</button>
		</form>
	</div>
</nav>
<?php } ?>


<?php function menu(){ ?>
<div class="menuad">
</div>
<?php } ?>


<?php function footerku(){ ?>

<div class="footer">
	&copy; dwndrr 2021
</div>

</body>
</html>
<?php } ?>