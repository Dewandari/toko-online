<?php 
require_once 'theme/fungsi.php';


session_destroy();

header('Location: ../index.php');

 ?>