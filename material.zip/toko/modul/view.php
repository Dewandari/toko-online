<?php 
require_once 'modul/conn_inc.php';

?>
<?php function headerku(){ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Cari Bangunan</title>
	<link rel="stylesheet" href="modul/ndari.css">
	<link rel="stylesheet" href="modul/style.css">
	<link rel="icon" type="img/png" href="gambar/logo.png">
</head>
<body>

<nav>
	<div class="konten">
	<b>Cari Bangunan</b>
		<ul>
			<a href="index.php"><li>Beranda</li></a>
			<a href="produk.php"><li>Produk</li></a>
			<a href="keranjang.php"><li>Keranjang <img src="img/cart2p.png" alt=""></li></a>
		</ul>
		<ul style="float: right;">
			<a href="admin/"><li>Login</li></a>
		</ul>
		<form action="produk.php" method="get">
			<input type="text" name="cari" placeholder="Cari...">
			<button>Cari</button>
		</form>
	</div>
</nav>
<?php } ?>


<?php 
if(isset($_POST['kirimkomen'])){
	$email = $_POST['email'];
	$komen = $_POST['komen'];
	if( !empty(trim($email)) && !empty(trim($komen)) ){
		if(komen($email,$komen)){
			header('Location:index.php');
		}else{echo 'gagal';}
	}else{echo 'jangan kosong';}
}

 ?>

<?php function footerku(){ ?>
<div class="footer">
	<div class="konten">
		<div class="r">
			<div class="kol-2">
				<img src="img/logo.png" alt="" width="200px">
				<img src="img/googleplus.png" alt="">
				<img src="img/facebook.png" alt="">
				<img src="img/whatsapp.png" alt="">				
			</div>
			<div class="kol-2">
				Cari Bangunan merupakan sebuah website yang menjual berbagai macam kebutuhan akan bangunan secara online.<br>
				Dengan adanya kehadiran Cari Bangunan maka Anda tidak perlu lagi repot untuk bisa mendapatkan segala kebutuhan akan bangunan dengan lebih cepat dan mudah, sehingga Anda bisa berbelanja dimana saja dan kapan saja. <br>
				<i style="color: #f44336;">pembayaran dilakukan di tempat atau dengan transfer bank, kartu kredit dan layanan COD </i> nantinya setelah dilakukan pembayaran, maka keperluan bangunan anda dikirim secara langsung ke rumah anda. <br>
			</div>
		</div>
	</div>
</div>
<div class="fotb">
	&copy; dwndrr 2021
</div>
</body>
</html>
<?php } ?>